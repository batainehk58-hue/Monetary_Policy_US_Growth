# Monetary Policy Tools and U.S. Economic Growth

Replication package for:

> Batayneh, K. *Monetary Policy Tools and U.S. Economic Growth: A Shadow-Rate Vector Error Correction Analysis, 2003–2025.*

The script estimates a six-variable VECM on quarterly U.S. data (2003:Q1–2025:Q4), with the Wu–Xia shadow rate as the policy stance and four crisis impulse dummies (2008:Q4, 2009:Q1, 2020:Q2, 2020:Q3). It reproduces every table, figure and number in the paper, and ends with an automated check list (205 checks) that compares each reported number with the estimated objects.

## Contents

| Path | Description |
|---|---|
| `estimation_code.py` | Full estimation script: data construction, unit-root and cointegration tests, VECM, impulse responses, variance decomposition, Granger causality, robustness checks, bootstrap (iid and wild) and figures |
| `data/GDPC1.csv` | Real GDP (FRED) |
| `data/UNRATE.csv` | Civilian unemployment rate (FRED) |
| `data/DPCCRV1Q225SBEA.csv` | Core PCE inflation (FRED) |
| `data/M2SL.csv` | M2 money stock (FRED) |
| `data/WALCL.csv` | Federal Reserve total assets (FRED) |
| `data/FEDFUNDS.csv` | Effective federal funds rate (FRED) |
| `data/WuXiaShadowRate.xlsx` | Wu–Xia shadow federal funds rate (Federal Reserve Bank of Atlanta) |
| `output/data_final.csv` | Quarterly estimation dataset built by the script |
| `output/results_final.json` | All estimated results and the check list |
| `output/orth_SSR.npy`, `output/orth_FFR.npy` | Orthogonalised impulse responses (main and nominal-rate models) |
| `output/fig1`–`fig4` `.png` | Figures 1–4 of the paper |

## Data sources

- Federal Reserve Bank of St. Louis, Federal Reserve Economic Data (FRED): https://fred.stlouisfed.org (retrieved July 2026).
- Federal Reserve Bank of Atlanta, Wu–Xia shadow federal funds rate: https://www.atlantafed.org/research-and-data/data/wu-xia-shadow-federal-funds-rate. The series ends in February 2022; the script splices it with the effective federal funds rate thereafter.
- Wu, J. C. and Xia, F. D. (2016), "Measuring the macroeconomic impact of monetary policy at the zero lower bound", *Journal of Money, Credit and Banking* 48(2–3): 253–291.

## How to run

Requirements: Python 3.10 or later, and the packages in `requirements.txt`. The results in the paper were produced with statsmodels 0.14.6; other versions may change some numbers slightly.

```
pip install -r requirements.txt
python estimation_code.py data
```

The argument is the folder holding the input data. Output files (`data_final.csv`, `results_final.json`, `.npy` arrays and figures) are written into that same folder. The bootstrap uses 1,000 replications with seed 11, so a full run takes several minutes.

## License

Code is released under the MIT License. The data are public series from FRED and the Federal Reserve Bank of Atlanta and remain subject to their providers' terms.
